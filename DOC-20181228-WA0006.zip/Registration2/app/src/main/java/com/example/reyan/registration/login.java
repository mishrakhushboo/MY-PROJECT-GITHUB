package com.example.reyan.registration;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Reyan on 3/17/2016.
 */
public class login extends Activity {
    SQLiteDatabase db;

    public void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.login);
        Button but = (Button) findViewById(R.id.button3);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent in = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(in);
            }
        });
        ImageButton i = (ImageButton) findViewById(R.id.imageButton);

        final EditText email = (EditText) findViewById(R.id.editText6);
        final EditText password = (EditText) findViewById(R.id.editText8);
        db = openOrCreateDatabase("Registration2_db", Context.MODE_PRIVATE, null);
        i.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (email.length() == 0) {

                    email.setError("Invalid Email-Id");
                }
                else
                {
                    Cursor c = db.rawQuery("SELECT * FROM trying WHERE email='" + email.getText() + "'AND password='" + password.getText() + "'", null);
                    if (c.moveToFirst())
                    {
                        Intent t = new Intent(getApplicationContext(), add.class);
                        startActivity(t);
                        finish();
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });


    }
}