package com.example.reyan.registration;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Reyan on 3/18/2016.
 */
public class add extends Activity {
    EditText editText,editText1,editText2;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle SavedInstanceState) {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.add);
        final Button button=(Button)findViewById(R.id.button11);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j=new Intent(getApplicationContext(),login.class);
                startActivity(j);
            }
        });


        db=openOrCreateDatabase("Registration2_db", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS Regis(Add_item VARCHAR,Price VARCHAR,Quantity VARCHAR);");
         editText1 = (EditText) findViewById(R.id.editText10);
         editText2 = (EditText) findViewById(R.id.editText11);
        final Button Vieww=(Button)findViewById(R.id.button5);
        Vieww.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               if(v==Vieww)
                {
                    if(editText.getText().toString().trim().length()==0)
                    {
                        showMessage("Error", "Please enter Item name");
                        return;
                    }
                    else
                    {
                        Cursor c = db.rawQuery("SELECT * FROM Regis WHERE Add_item='" + editText.getText() + "'", null);
                        if (c.moveToFirst()) {
                            editText.setText(c.getString(0));
                            editText1.setText(c.getString(1));
                            editText2.setText(c.getString(2));
                        } else {
                            showMessage("Error", "Invalid Entry");
                            // clearText();
                        }
                    }
                }
                Intent intent=new Intent(getApplicationContext(),show.class);
                startActivity(intent);
            }
        });
        final Button delete = (Button) findViewById(R.id.button7);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (v == delete) {
                    if (editText.getText().toString().trim().length() == 0) {
                        showMessage("error", "PLS ENTER PRODUCT NAME");
                        return;
                    }
                    Cursor c=db.rawQuery("SELECT * FROM Regis WHERE Add_item='"+editText.getText()+"'", null);
                    if (c.moveToFirst())
                    {
                        db.execSQL("DELETE FROM Regis WHERE Add_item='" + editText.getText() + "'");
                        showMessage("success", "record deleted");
                    }
                    else
                    {
                        showMessage("error","invalid item name");
                    }
                }
            }
        });
       final Button modify=(Button)findViewById(R.id.button6);
        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editText.getText().toString().trim().length()==0)
                {
                    showMessage("error","PLS ENTER ITEM NAME");
                    return;
                }
                Cursor c=db.rawQuery("SELECT * FROM Regis WHERE Add_item='"+editText.getText()+"'", null);
                if (c.moveToFirst())
                {
                  db.execSQL("UPDATE Regis SET Price='"+editText1.getText().toString()+"',Quantity='"+editText1.getText().toString()+
                  "'WHERE Add_item='"+editText.getText().toString()+"'");
                    showMessage("Success","record modified");
                }
                else
                {
                    showMessage("error","invalid Add_item");
                }
                clearText();
            }
        });
        final Button VI=(Button)findViewById(R.id.button8);
        VI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(v==VI)
                {
                    Cursor c=db.rawQuery("SELECT * FROM Regis", null);
                    if(c.getCount()==0)
                    {
                        showMessage("Error", "No records found");

                        return;

                    }
                    StringBuffer buffer=new StringBuffer();
                    while(c.moveToNext())
                    {
                        buffer.append("Add_item: "+c.getString(0)+"\n");
                        buffer.append("Price: "+c.getString(1)+"\n");
                        buffer.append("Quantity: "+c.getString(2)+"\n\n");
                    }
                    showMessage("Registration Detail", buffer.toString());
                }
            }
        });
       final Button Add=(Button)findViewById(R.id.button4);
        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if      (   (editText.getText().toString().equals(""))
                        || (editText1.getText().toString().equals(""))
                        || (editText2.getText().toString().equals(""))
                        ) {
                    editText.setError("Please enter all field");
                    editText1.setError("Please enter all field");
                    editText2.setError("Please enter all field");

                }
                else
                {
                    db.execSQL("INSERT INTO  Regis VALUES('" + editText.getText().toString() + "','" + editText1.getText().toString() + "','" + editText2.getText().toString() + "');");
                    Toast.makeText(getApplicationContext(), "record added", Toast.LENGTH_LONG).show();
                }

            }
        });
    }
    private void showMessage(String title, String message) {

        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();

    }
    public void clearText()
    {
        editText.setText("");
        editText1.setText("");
        editText2.setText(" ");
        editText.requestFocus();
    }

}




