package com.example.reyan.registration;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;

/**
 * Created by Reyan on 3/17/2016.
 */
public class splash extends Activity {
    private static int SPLASH_TIME=3500;
    protected void onCreate(Bundle SavedInstanceState){
        super.onCreate(SavedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.splash);
        new android.os.Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=new Intent(getApplicationContext(),pge1.class);
                startActivity(intent);
            }
        },SPLASH_TIME);

    }

}
