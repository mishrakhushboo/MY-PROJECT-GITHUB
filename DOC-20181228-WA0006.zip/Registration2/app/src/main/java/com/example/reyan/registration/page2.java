package com.example.reyan.registration;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by Reyan on 3/15/2016.
 */
public class page2 extends Activity {
    SQLiteDatabase db;

    private String name,password,phone,address,email,gender;

    protected void onCreate(Bundle savedStateInstance){
        super.onCreate(savedStateInstance);
        setContentView(R.layout.page2);
        db=openOrCreateDatabase("Registration2_db", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS trying("
                + "name VARCHAR,"
                + "phone VARCHAR primary key,"
                + "password VARCHAR,"
                + "address VARCHAR,"
                + "email VARCHAR UNIQUE,"
                + "gender VARCHAR);");

        Button b2=(Button) findViewById(R.id.button2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextpage();
            }


            public void nextpage(){
                if(check()){
                    intent_fn();
                }
            }
            public boolean check(){
                EditText pa=(EditText)findViewById(R.id.editText5);
                EditText email=(EditText)findViewById(R.id.editText7);
                RadioGroup rg=(RadioGroup)findViewById(R.id.radioGroup);
                RadioButton gender = (RadioButton) findViewById(rg.getCheckedRadioButtonId());

                if(pa.getText().toString().equals(""))
                {
                    pa.setError("Address Must Be Filled");
                    return false;
                }
                else if(email.getText().toString().equals(""))
                {
                    email.setError("Enter The Email");
                    return false;
                }
                else if (email.getText().toString().indexOf("@") == -1)
                {
                    email.setError("Enter Valid Email");
                    return false;
                }
                else if(rg.getCheckedRadioButtonId() == -1)
                {
                    Toast.makeText(getApplicationContext(), "Select Your Gender", Toast.LENGTH_SHORT).show();
                    return false;
                }
                else
                {
                    putValue(pa.getText().toString(),email.getText().toString(),gender.getText().toString());
                    return updateDB();
                }
            }

            private boolean updateDB() {

                try {
                    db.execSQL("INSERT INTO trying("
                            + "name,"
                            + "phone,"
                            + "password,"
                            + "address,"
                            + "email,"
                            + "gender) "
                            + "VALUES('" + name + "', "
                            + "'" + phone + "', "
                            + "'" + password + "', "
                            + "'" + address + "', "
                            + "'" + email + "', "
                            + "'" + gender + "');");

                    Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                    return true;
                }
                catch (Exception e)
                {
                    AlertMsg("Error", e.toString());
                    return false;
                }
            }


            private void putValue(String a,String b,String c) {

                Intent intent = getIntent();
                Bundle bundle = intent.getExtras();

                name = (String) bundle.get("name");
                phone = (String) bundle.get("phone");
                password = (String) bundle.get("password");
                address = a;
                email = b;
                gender = c;

            }
            public void intent_fn () {
                    try {
                        Intent in = new Intent(getApplicationContext(), page3.class);
                        startActivity(in);
                        finish();
                    }
                    catch (Exception e){
                        AlertMsg("Error",e.toString());
                    }

            }

        });
    }
private void AlertMsg(String title,String message) {

        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}