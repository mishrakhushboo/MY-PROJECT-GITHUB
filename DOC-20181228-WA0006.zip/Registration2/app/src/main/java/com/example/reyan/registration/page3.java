package com.example.reyan.registration;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Reyan on 3/16/2016.
 */
public class page3 extends Activity {
    public void onCreate(Bundle SavedInstanceState){
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.page3);

    }
}
