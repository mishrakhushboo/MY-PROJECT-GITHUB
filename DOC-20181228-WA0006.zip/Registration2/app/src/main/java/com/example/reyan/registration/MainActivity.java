package com.example.reyan.registration;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.reyan.registration.R;
import com.example.reyan.registration.page2;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b=(Button) findViewById(R.id.button);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextpage();
            }
        });
    }
    private void nextpage(){
        if(check()){
            intent_fn();
        }
    }
    public boolean check(){
        EditText name=(EditText)findViewById(R.id.editText);
        EditText phone=(EditText)findViewById(R.id.editText2);
        EditText password=(EditText)findViewById(R.id.editText3);
        EditText password2=(EditText)findViewById(R.id.editText4);
        CheckBox check=(CheckBox)findViewById(R.id.checkBox);
        if(name.getText().toString().equals(""))
        {
            name.setError("Enter The Name");
            return false;
        }
        else if (phone.getText().toString().length()<10)
        {
            phone.setError("Number Must Contain 10 Digits");
            return false;
        }
        else if(password.getText().toString().length()<8)
        {
            password.setError("Password Should Contains Atleast 8 Character");
            return false;
        }
        else if (!(password.getText().toString().equals(password2.getText().toString())))
        {
            password2.setError("Password Do Not Match");
            return false;
        }
        else if (!check.isChecked())
        {
            Toast.makeText(getApplicationContext(),"Please Aceept The Terms And Condition",Toast.LENGTH_SHORT).show();
            return false;
        }
        else
        {
            return true;
        }



    }
    public void intent_fn(){
        EditText name=(EditText)findViewById(R.id.editText);
        EditText phone=(EditText)findViewById(R.id.editText2);
        EditText password=(EditText)findViewById(R.id.editText3);
        Intent i=new Intent(getApplication(),page2.class);

        i.putExtra("name", name.getText().toString());
        i.putExtra("phone", phone.getText().toString());
        i.putExtra("password",password.getText().toString());
        startActivity(i);
        finish();
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
